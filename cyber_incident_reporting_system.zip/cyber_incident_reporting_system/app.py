import os
import sqlite3
from datetime import datetime, timezone
from flask import Flask, render_template, request, redirect, url_for, flash, g, abort

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(BASE_DIR, "incident_reporting.db"))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-in-production")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    with open(os.path.join(BASE_DIR, "schema.sql"), "r", encoding="utf-8") as f:
        db.executescript(f.read())
    db.commit()

@app.route("/")
def dashboard():
    db = get_db()
    stats = db.execute("""
        SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN status='Open' THEN 1 ELSE 0 END) AS open_count,
          SUM(CASE WHEN severity='Critical' THEN 1 ELSE 0 END) AS critical_count,
          SUM(CASE WHEN status='Resolved' THEN 1 ELSE 0 END) AS resolved_count
        FROM incidents
    """).fetchone()
    recent = db.execute("""
        SELECT i.*, a.name AS attack_name
        FROM incidents i
        JOIN attack_types a ON a.id = i.attack_type_id
        ORDER BY i.created_at DESC
        LIMIT 8
    """).fetchall()
    return render_template("dashboard.html", stats=stats, incidents=recent)

@app.route("/incidents")
def incidents():
    db = get_db()
    status = request.args.get("status", "")
    severity = request.args.get("severity", "")
    query = """
        SELECT i.*, a.name AS attack_name
        FROM incidents i
        JOIN attack_types a ON a.id = i.attack_type_id
        WHERE 1=1
    """
    params = []
    if status:
        query += " AND i.status = ?"
        params.append(status)
    if severity:
        query += " AND i.severity = ?"
        params.append(severity)
    query += " ORDER BY i.created_at DESC"
    rows = db.execute(query, params).fetchall()
    return render_template("incidents.html", incidents=rows, selected_status=status, selected_severity=severity)

@app.route("/incidents/new", methods=["GET", "POST"])
def new_incident():
    db = get_db()
    attacks = db.execute("SELECT * FROM attack_types ORDER BY name").fetchall()
    if request.method == "POST":
        reporter_name = request.form.get("reporter_name", "").strip()
        reporter_email = request.form.get("reporter_email", "").strip()
        attack_type_id = request.form.get("attack_type_id", "").strip()
        severity = request.form.get("severity", "").strip()
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        affected_asset = request.form.get("affected_asset", "").strip()
        detected_at = request.form.get("detected_at", "").strip()

        allowed_severity = {"Low", "Medium", "High", "Critical"}
        if not all([reporter_name, reporter_email, attack_type_id, severity, title, description, affected_asset]):
            flash("Please complete all required fields.", "error")
            return render_template("new_incident.html", attacks=attacks)
        if severity not in allowed_severity:
            flash("Invalid severity.", "error")
            return render_template("new_incident.html", attacks=attacks)
        if len(title) > 160 or len(description) > 5000:
            flash("Title or description is too long.", "error")
            return render_template("new_incident.html", attacks=attacks)

        try:
            attack_id = int(attack_type_id)
        except ValueError:
            flash("Invalid attack type.", "error")
            return render_template("new_incident.html", attacks=attacks)

        exists = db.execute("SELECT id FROM attack_types WHERE id=?", (attack_id,)).fetchone()
        if not exists:
            flash("Invalid attack type.", "error")
            return render_template("new_incident.html", attacks=attacks)

        now = datetime.now(timezone.utc).isoformat()
        db.execute("""
            INSERT INTO incidents
            (reporter_name, reporter_email, attack_type_id, severity, title,
             description, affected_asset, detected_at, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Open', ?, ?)
        """, (reporter_name, reporter_email, attack_id, severity, title,
              description, affected_asset, detected_at or now, now, now))
        db.commit()
        flash("Incident reported successfully.", "success")
        return redirect(url_for("incidents"))

    return render_template("new_incident.html", attacks=attacks)

@app.route("/incidents/<int:incident_id>")
def incident_detail(incident_id):
    db = get_db()
    incident = db.execute("""
        SELECT i.*, a.name AS attack_name, a.description AS attack_description
        FROM incidents i
        JOIN attack_types a ON a.id = i.attack_type_id
        WHERE i.id=?
    """, (incident_id,)).fetchone()
    if incident is None:
        abort(404)
    return render_template("incident_detail.html", incident=incident)

@app.route("/incidents/<int:incident_id>/status", methods=["POST"])
def update_status(incident_id):
    status = request.form.get("status", "")
    if status not in {"Open", "Investigating", "Contained", "Resolved"}:
        abort(400)
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    cur = db.execute("UPDATE incidents SET status=?, updated_at=? WHERE id=?",
                     (status, now, incident_id))
    db.commit()
    if cur.rowcount == 0:
        abort(404)
    flash("Incident status updated.", "success")
    return redirect(url_for("incident_detail", incident_id=incident_id))

@app.route("/attack-types")
def attack_types():
    db = get_db()
    attacks = db.execute("""
        SELECT a.*, COUNT(i.id) AS incident_count
        FROM attack_types a
        LEFT JOIN incidents i ON i.attack_type_id = a.id
        GROUP BY a.id
        ORDER BY a.name
    """).fetchall()
    return render_template("attack_types.html", attacks=attacks)

@app.route("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    with app.app_context():
        if not os.path.exists(DB_PATH):
            init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
