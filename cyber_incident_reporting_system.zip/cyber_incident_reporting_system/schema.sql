PRAGMA foreign_keys = ON;

DROP TABLE IF EXISTS incidents;
DROP TABLE IF EXISTS attack_types;

CREATE TABLE attack_types (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL,
    typical_indicators TEXT NOT NULL
);

CREATE TABLE incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_name TEXT NOT NULL,
    reporter_email TEXT NOT NULL,
    attack_type_id INTEGER NOT NULL,
    severity TEXT NOT NULL CHECK (severity IN ('Low','Medium','High','Critical')),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    affected_asset TEXT NOT NULL,
    detected_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open'
        CHECK (status IN ('Open','Investigating','Contained','Resolved')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (attack_type_id) REFERENCES attack_types(id)
);

CREATE INDEX idx_incidents_status ON incidents(status);
CREATE INDEX idx_incidents_severity ON incidents(severity);
CREATE INDEX idx_incidents_attack_type ON incidents(attack_type_id);
CREATE INDEX idx_incidents_created_at ON incidents(created_at);

INSERT INTO attack_types (id, name, description, typical_indicators) VALUES
(1, 'Phishing', 'Deceptive messages designed to trick users into revealing information or taking unsafe actions.', 'Suspicious links, spoofed senders, urgent language, unexpected attachments'),
(2, 'Ransomware', 'Malware incident involving unauthorized encryption or disruption of data and systems.', 'Unavailable files, unusual extensions, ransom notes, abnormal file activity'),
(3, 'Malware Infection', 'Unauthorized malicious software executing on a workstation, server, or other endpoint.', 'Endpoint alerts, unknown processes, persistence artifacts, unexpected outbound traffic'),
(4, 'Credential Theft', 'Unauthorized acquisition or attempted acquisition of passwords, tokens, or authentication material.', 'Impossible-travel alerts, repeated login failures, token anomalies, suspicious authentication'),
(5, 'DDoS Attack', 'Distributed traffic intended to exhaust network, application, or service resources.', 'Traffic spikes, elevated latency, packet floods, service availability degradation'),
(6, 'SQL Injection', 'Attempts to manipulate application database queries through untrusted input.', 'Database errors, anomalous query patterns, suspicious input strings, WAF alerts'),
(7, 'Cross-Site Scripting (XSS)', 'Injection of client-side script into web content viewed by users.', 'WAF alerts, suspicious parameters, unexpected script execution, altered page content'),
(8, 'Unauthorized Access', 'Access to systems, accounts, or data without appropriate authorization.', 'Unexpected account activity, privilege anomalies, unfamiliar source locations'),
(9, 'Data Exfiltration', 'Unauthorized transfer of organizational data to an external destination.', 'Large outbound transfers, unusual destinations, archive creation, DLP alerts'),
(10, 'Insider Threat', 'Potentially harmful activity involving an authorized user or trusted access path.', 'Unusual access patterns, policy violations, bulk downloads, abnormal privilege use');

INSERT INTO incidents
(reporter_name, reporter_email, attack_type_id, severity, title, description, affected_asset, detected_at, status, created_at, updated_at)
VALUES
('Aarav Mehta', 'aarav.mehta@example.test', 1, 'High',
 'Suspicious payroll email reported',
 'Employee received a message impersonating the finance team and reported the embedded link before entering credentials.',
 'Finance workstation FIN-WS-014',
 '2026-09-16T09:20:00+05:30', 'Investigating',
 '2026-09-16T09:28:00+05:30', '2026-09-16T10:05:00+05:30'),

('Maya Sharma', 'maya.sharma@example.test', 3, 'Critical',
 'Endpoint malware alert',
 'EDR generated a high-confidence malware alert on a demonstration endpoint. The host was isolated for investigation.',
 'Demo endpoint DEMO-WS-07',
 '2026-09-15T14:10:00+05:30', 'Contained',
 '2026-09-15T14:15:00+05:30', '2026-09-15T15:00:00+05:30'),

('Kabir Singh', 'kabir.singh@example.test', 8, 'Medium',
 'Unexpected administrative login',
 'An administrative account was observed logging into a test server outside its normal maintenance window.',
 'Test server LAB-SRV-02',
 '2026-09-14T22:40:00+05:30', 'Open',
 '2026-09-14T22:47:00+05:30', '2026-09-14T22:47:00+05:30'),

('Anaya Rao', 'anaya.rao@example.test', 5, 'High',
 'Traffic surge affecting demo service',
 'Monitoring detected a sustained traffic spike against a public demonstration service, causing elevated response times.',
 'Demo web service DEMO-WEB-01',
 '2026-09-13T17:35:00+05:30', 'Resolved',
 '2026-09-13T17:42:00+05:30', '2026-09-13T19:10:00+05:30'),

('Vihaan Kapoor', 'vihaan.kapoor@example.test', 6, 'High',
 'Possible database injection attempt',
 'Application security monitoring flagged repeated malformed input against a demo search endpoint.',
 'Demo application DEMO-APP-03',
 '2026-09-12T11:30:00+05:30', 'Investigating',
 '2026-09-12T11:36:00+05:30', '2026-09-12T12:20:00+05:30');
